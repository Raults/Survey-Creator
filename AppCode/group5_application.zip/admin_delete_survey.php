<?php
include('Online_Surveys.dbconfig.inc');
?>


<html>
<head> ADMIN Delete Survey Page
<title>

</title>
</head>
<body> 





</body>
</html>
